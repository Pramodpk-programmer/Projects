import boto3
import os
import pandas as pd
from pathlib import Path
import time
from datetime import datetime
import datetime as dt
import json
import email, imaplib
import smtplib
import imghdr
from email.message import EmailMessage

T = None

# S3 Coonector Class
class S3ConnectorClass():
    def __init__(self):
        print("Inside S3 connector class")

    def download(self, s3_conn_parameter, logger, prog_logger):                                  # Downloading files from S3 Bucket
        start = time.time()
        logger.info("Files download process started")
        prog_logger.addLog(datetime.now(), "Files download process started")
        print("Download files from S3 Bucket process started")
        publisherName = s3_conn_parameter.get('publisher_name')
        inputpath = s3_conn_parameter.get('inputFilePath')   
        bucketName = s3_conn_parameter.get('bucket_name')  
        T = dt.datetime.now().strftime("%m%d%Y%H%M")                                             
        print(publisherName)
        print(inputpath)
        print(bucketName)
        s3 = boto3.client('s3')
        list_length = None
        processPath = "ProcessFiles/"+publisherName+"/"+str(T)
        try:
            list=s3.list_objects(Bucket='avng-app-engg', Prefix=inputpath)['Contents']
            print("Length of list",len(list))
            list_length = len(list)
            for key in list:
                f = key['Key']
                sourcePath = f
                file = f.replace(inputpath+"/", "")
                filename = file.rsplit('.',-1)[0]
                print("Filename: ", filename)
                extention = file.rsplit('.',-1)[1]
                print("Extention: ", extention)
                if not os.path.exists(processPath):
                    os.makedirs(processPath)
                else: 
                    pass        
                if extention == "EXT":
                    destinationPath = processPath+"/"+filename+".txt"
                else:
                    destinationPath = processPath+"/"+filename+"."+extention
                s3.download_file(bucketName, sourcePath, destinationPath) 
                print("File Downloaded")
            print("Files Downloaded from S3 Bucket")
            end = time.time()
            input_latency = end - start
            logger.info("Files downloaded successfully")
            prog_logger.addLog(datetime.now(), "Files downloaded successfully")
            return {"processPath": processPath, "filesDownloaded": True, "source_latency": input_latency}
        except:
            print("Error while downloading files")
            if list_length == None:   
               print("No files present in the specified sourcePath")
               logger.info("No files present in the specified source path")
               prog_logger.addLog(datetime.now(), "No files present in the specified source path")
            end = time.time()
            input_latency = end - start
            logger.info("Failed to download files from S3 Bucket")
            prog_logger.addLog(datetime.now(), "Failed to download files from S3 Bucket")
            return {"processPath": processPath, "filesDownloaded": False, "source_latency": input_latency}

    def upload(self, s3_conn_parameter, outputFilePath, logger, prog_logger):                                                       # Uploading files to S3 Bucket
        start = time.time()
        logger.info("Upload files to S3 Bucket process started")
        prog_logger.addLog(datetime.now(), "Upload files to S3 Bucket process started")
        print("Uploading files to S3 Bucket")
        T = dt.datetime.now().strftime("%m%d%Y%H%M") 
        publisherName = s3_conn_parameter.get('publisher_name')
        bucketName = s3_conn_parameter.get('bucket_name') 
        outputpath = s3_conn_parameter.get('OutputFilePath') 
        outputFileExtention = s3_conn_parameter.get('output_file_extension')
        print(publisherName)
        print(outputpath)
        print(bucketName)
        s3 = boto3.client("s3")
        try:
            for r, d, f in os.walk(outputFilePath):
                count = 0
                for file in f:
                    count = count + 1
                    s3.upload_file(outputFilePath+"/"+file, bucketName, outputpath+publisherName+"/"+"merged_file"+"_"+str(count)+"Date"+str(T)+outputFileExtention)
                    print("S3 Bucket Output File Path: ", outputpath+publisherName+"/"+"merged_file"+"_"+str(count)+"Date"+str(T)+outputFileExtention)
                    OutputFileName = outputpath+publisherName+"/"+"merged_file"+"_"+str(count)+"Date"+str(T)+outputFileExtention
            print("Files Uploaded to S3 Bucket")
            end = time.time()
            output_latency = end - start
            logger.info("Files uploaded successfully")
            prog_logger.addLog(datetime.now(), "Files uploaded successfully")
            return {"OutputFilePath": outputpath, "OutputFileName": OutputFileName, "files_uploaded": True, "destination_latency": output_latency}
        except:
            print("Failed to Upload files to S3 Bucket")
            end = time.time()
            output_latency = end - start
            logger.info("Failed to Upload files to S3 Bucket")
            prog_logger.addLog(datetime.now(), "Failed to Upload files to S3 Bucket")
            return {"OutputFilePath": outputpath, "files_uploaded": False, "destination_latency": output_latency}

# Email Connector Class
class EmailConnectorClass():
    def __init__(self):
        print("Inside Email Connector class")

    def download(self, email_conn_parameter, logger, prog_logger):                                             # Downloading files from Email 
        try:
            print("Downloading files from Email connection")
            start = time.time()
            user_name = email_conn_parameter.get('username')
            password = email_conn_parameter.get('password')
            smtp_host = email_conn_parameter.get('smtp_host')
            # port = email_conn_parameter.get('port')
            path = "ProcessFiles"
            sender = email_conn_parameter.get('sender')
            publisher = email_conn_parameter.get('publisher_name')

            # get body
            def get_body(msg):
                try:
                    if msg.is_multipart():
                        for part in msg.walk():
                            if part.get_content_type() == 'text/plain':
                                body= part.get_payload(decode= True)
                                body = str(body, 'utf-8')
                                return body
                    else:
                        return msg.get_payload(None, True)
                except:
                    print("Failed to load body of the mail")
            # get attachments:
            def get_attachments(msg, sender, Path):
                T = dt.datetime.now().strftime("%m-%d-%Y__%H-%M")
                try:
                    for part in msg.walk():
                        if part.get_content_maintype() == 'multipart':
                            continue
                        if part.get('Content-Disposition') is None:
                            continue
                        fileName = part.get_filename()
                        if bool(fileName):
                            filePath = os.path.join(Path, publisher)
                            filePath = os.path.join(filePath, sender)
                            mainFilePath = os.path.join(filePath, str(T))
                            filePath = os.path.join(mainFilePath, "InputFiles")
                            print(filePath)
                            if not os.path.exists(filePath):
                                os.makedirs(filePath)
                            else:
                                print("FilePath exist")
                            filepath = os.path.join(filePath, fileName)
                            with open(filepath, 'wb') as f:
                                f.write(part.get_payload(decode=True))
                    return filePath
                except:
                    print("Failed to save files in folder")    
            # mail login/
            def mail_login():
                print("Creating login connection with mail credentials")
                mail = imaplib.IMAP4_SSL(str(smtp_host))
                mail.login(user_name, password)
                print("Logged in")
                mail.select('inbox')
                pk = ("%s" % sender )
                print("Sender is ", pk)
                type, data = mail.search(None, '(from "{}")'.format(sender))
                print("Search Type ",type)
                # iterating through mails
                try:
                    for num in data[0].split():
                        print("Iterating mails")
                        typ, data = mail.fetch(num, '(RFC822)')
                        print("Mail Type: ", typ)
                        raw_email = data[0][1]
                        raw_email_string = raw_email.decode('utf-8')
                        email_message = email.message_from_string(raw_email_string)
                        Sender = email_message['from']
                        print("Sender: ", Sender)
                        name = Sender.split('<', maxsplit=1)[0]
                        name = name.replace(' ', '').replace('\"', "")
                        print("name: ", name)
                        print("Subject: ",email_message['Subject'])
                        msg = get_body(email.message_from_bytes(raw_email))
                        print("Body: ", msg)
                        result, data = mail.fetch(num, '(RFC822)')
                        print("Result: ", result)
                        raw = email.message_from_bytes(data[0][1])
                        filePath = get_attachments(raw, name, path)
                        print(filePath)
                    return {'filePath': filePath, 'filesDownloaded': True}
                except:
                    print("There is no new mails from the specified sender: "+sender )
                    return {'filesDownloaded': False}

            File_Path = mail_login()
            if File_Path.get('filesDownloaded'):
                end = time.time()
                input_latency = end - start
                logger.info("Files successfully downloaded from email")
                prog_logger.addLog(datetime.now(), "Files successfully downloaded from email")
                return {'processPath': File_Path.get('filePath'), "filesDownloaded": True, "source_latency": input_latency}
            else:
                print("Input process failed")
                end = time.time()
                input_latency = end - start
                print("Source Latency: ", input_latency)
                logger.info("Failed: No new mails to download files")
                prog_logger.addLog(datetime.now(), "Failed: No new mails to download files")
                return {"filesDownloaded": False, "source_latency": input_latency}
        except:
            print("Input process failed")
            end = time.time()
            input_latency = end - start
            print("Source Latency: ", input_latency)
            logger.info("Failed to download files from email")
            prog_logger.addLog(datetime.now(), "Failed to download files from email")
            return {"filesDownloaded": False, "source_latency": input_latency}


    def upload(self, email_conn_parameter, outputFilePath, logger, prog_logger):                                                       # Sending files through email connection
        print("Sending files through Email Connection")
        try:
            start = time.time()
            user_name = email_conn_parameter.get('username')
            password = email_conn_parameter.get('password')
            smtp_host = email_conn_parameter.get('smtp_host')
            port = email_conn_parameter.get('port')
            publisher = email_conn_parameter.get('publisher_name')
            receiver_mail = email_conn_parameter.get('receiver_mail')
            print("Output File Path: ",outputFilePath)

            msg = EmailMessage()
            msg['Subject'] = 'Processed output files for {}'.format(str(publisher))
            msg['From'] = "shaktig5544@gmail.com"
            contacts = receiver_mail
            msg['To'] = contacts
            msg.set_content("Input files are processed and merged into an output files, \n Please find the attachments. \n\n Thanks and Regards, \n Shakti.")
            print("Setup Done!")
            # Attachment
            files = []
            for file in os.listdir(Path(outputFilePath)):
                files.append(file)
            for file1 in files:
                file2 = os.path.join(outputFilePath, file1)
                with open(file2, 'rb') as f:
                    file_data = f.read()
                msg.add_attachment(file_data, maintype='application', subtype='octet_stream', filename=file1)
                print("Files attached")
            # Send mail
            print("Sending mails")
            with smtplib.SMTP_SSL(str(smtp_host), str(port)) as smtp:
                smtp.login(str(user_name), str(password))
                smtp.send_message(msg)
            print("Mail sent successfully")
            end = time.time()
            output_latency = end - start
            print("destination_latency: ", output_latency)
            logger.info("Files uploaded successfully")
            prog_logger.addLog(datetime.now(), "Files uploaded successfully")
            return {"files_uploaded": True,"OutputFileName": "File sent throught mail", "destination_latency": output_latency}

        except:
            print("Failed to send files through email")
            end = time.time()
            output_latency = end - start
            print("destination_latency: ", output_latency)
            logger.info("Failed to send files through email")
            prog_logger.addLog(datetime.now(), "Failed to send files through email")
            return {"files_uploaded": False, "destination_latency": output_latency}


# MySql Connector Class
class MySqlConnectorClass():
    def __init__(self):
        print("Inside Email Connector class")

    def download(self, mysql_conn_parameter, looger, prog_logger):                                                     # Getting files from mysql database
        print("Getting files from mysql database")

    def upload(self, mysql_conn_parameter, outputFilePath, logger, prog_logger):                                                       # Uploading files to mysql database
        print("Uploading files to mysql database")