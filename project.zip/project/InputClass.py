import time

from ConnectorClasses import S3ConnectorClass, EmailConnectorClass, MySqlConnectorClass

class InputClass():
    def __init__(self, input_conn_parameters, input_connection_type, logger, prog_logger):
        print("Inside Input Class")
        self.type = input_connection_type
        self.connection_parameter = input_conn_parameters
        self.logger = logger
        self.prog_logger = prog_logger
        
    def get_Files(self):
        if self.type == "email":
            email_conn_obj = EmailConnectorClass()
            response = email_conn_obj.download(self.connection_parameter, self.logger, self.prog_logger)
            return response
        elif self.type == "s3":
            s3_conn_obj = S3ConnectorClass()
            processFilePath = s3_conn_obj.download(self.connection_parameter, self.logger, self.prog_logger)
            return processFilePath
        elif self.type == "mysql":
            mysql_conn_obj = MySqlConnectorClass()
            mysql_conn_obj.download(self.connection_parameter, self.logger, self.prog_logger)
        elif self.type == "api":
            pass
        elif self.type == "athena":
            pass