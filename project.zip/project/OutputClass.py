import time

from ConnectorClasses import S3ConnectorClass, EmailConnectorClass, MySqlConnectorClass


class OutputClass():
    def __init__(self, output_conn_parameters, output_connection_type, logger, prog_logger):
        print("Inside Output Class")
        self.type = output_connection_type
        self.connection_parameters = output_conn_parameters
        self.logger = logger
        self.prog_logger = prog_logger

    def put_Files(self, outputFilePath):
        if self.type == "email":
            email_conn_obj = EmailConnectorClass()
            outputResponse = email_conn_obj.upload(self.connection_parameters, outputFilePath, self.logger, self.prog_logger)
            return outputResponse

        elif self.type == "s3":
            s3_conn_obj = S3ConnectorClass()
            outputResponse = s3_conn_obj.upload(self.connection_parameters, outputFilePath, self.logger, self.prog_logger)
            return outputResponse
        elif self.type == "mysql":
            mysql_conn_obj = MySqlConnectorClass()
            mysql_conn_obj.upload(self.connection_parameters, outputFilePath, self.logger, self.prog_logger)
