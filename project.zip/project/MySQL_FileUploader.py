import pandas as pd
import pymysql
import os
import json

class MySQL_FileUploader:
    def __init__(self):
        print("Inside MySQL File Uploader Class")

    def upload(self):
        
        mydb = pymysql.connect(
            host="localhost",
            port=3306,
            user="root",
            passwd="root",
            db="advangelists",
        )
        mycursor = mydb.cursor()
        # Query
        sql = "INSERT INTO output_data(ad_tag, ad_url_path, ad_snapshot, malware, phishing, bdomain, landing_page, \
            autoredirect, ad_onload_har, ad_onload_har_pixel_domains, ad_onload_har_request_header_replace, \
            ad_har_file, malwares, request_id, landing_snapshot, landing_har, autoredirect_url, status, latency,\
            ad_loading_latency, click, har) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        # Reading Output Json File
        json_open = open('Raunak_Output_File.json', encoding="utf-8")
        json_obj = json.load(json_open)
        print(json_obj.get('Request').get('malware'))
        req = json_obj.get('Request')
        res = json_obj.get('Response')
        # Values
        # Request Parameters
        ad_tag = req.get('ad_tag')
        ad_url_path = req.get('ad_url_path')
        print(ad_url_path)
        ad_snapshot = req.get('ad_snapshot')
        malware =req.get('malware')
        phishing = req.get('phishing')
        bdomain =req.get('bdomain')
        landing_page = req.get('landing_page')
        autoredirect = req.get('autoredirect')
        ad_onload_har = req.get('ad_onload_har')
        ad_onload_har_pixel_domains = req.get('ad_onload_har_pixel_domains')
        ad_onload_har_request_header_replace = req.get('ad_onload_har_request_header_replace')
        # Response Parameters
        ad_har_file = res.get('ad_har_file')
        malwares = res.get('malwares')
        request_id = res.get('request_id')
        landing_snapshot = res.get('landing_snapshot')
        landing_har = res.get('landing_har')
        autoredirect_url = res.get('autoredirect_url')
        status = res.get('status')
        latency = res.get('latency')
        ad_loading_latency = res.get('ad_loading_latency')
        click = res.get('click')
        har = res.get('har')
        # Adding values
        values = (ad_tag, ad_url_path, ad_snapshot, malware, phishing, bdomain, landing_page, \
            autoredirect, ad_onload_har, ad_onload_har_pixel_domains, ad_onload_har_request_header_replace, \
            ad_har_file, malwares, request_id, landing_snapshot, landing_har, autoredirect_url, status, latency,\
            ad_loading_latency, click, har)
        # Executing Query
        print(values)
        print(sql)
        mycursor.execute(sql, values)
        mydb.commit()
        print("Data uploaded")

class_obj = MySQL_FileUploader()
class_obj.upload()