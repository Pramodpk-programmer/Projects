import time
from datetime import datetime
import pandas as pd
import os
import time
import datetime as dt

T = None

class ProcessClass():
    def __init__(self, process_parameters, logger, prog_logger):
        print("Inside Process Class")
        self.maxLineCount = process_parameters.get('max_line_count')
        self.header = process_parameters.get('is_header_present')
        self.delimiter = process_parameters.get('delimiter')
        self.outputFileExtention = process_parameters.get('output_file_extension')
        self.publisherName = process_parameters.get('publisherName')
        self.logger = logger
        self.prog_logger = prog_logger

    def process(self, processPath):
        start = time.time()
        self.logger.info("Processing files")
        self.prog_logger.addLog(datetime.now(), "Processing files")
        T = dt.datetime.now().strftime("%m%d%Y%H%M")
        print("Processing files")
        print("Found process path is : ", processPath)
        outputFilePath = "ProcessedFiles/"+self.publisherName+"/"+str(T)
        try:
            df = []
            for file in os.listdir(processPath):
                print(file)
                extention = file.rsplit('.',-1)[1]
                if extention == "xlsx":                                                        # Excel File read
                    print("Excel files")                                       
                    p = (pd.read_excel(processPath+"/"+file, header=None))
                    df = p.append(p)

                elif extention == "csv":                                                       # CSV File read
                    print("CSV Files")                                          
                    p = (pd.read_csv(processPath+"/"+file, sep=self.delimiter, header=None))
                    df = p.append(p)

                elif extention == "txt":                                                       # Email Text file
                    print("ext file")
                    p = (pd.read_csv(processPath+"/"+file, sep=self.delimiter, header=None))
                    df = p.append(p)

                elif extention == "json":                                                      # JSON File read
                    print("JSON file")
                    with open(processPath+"/"+file, 'r') as myfile:
                        data=myfile.read()
                    obj = json.loads(data)
                    df = pd.DataFrame.from_dict(obj, orient='columns')

                else:
                    print("No Files Found")
            row_count = df.shape[0]
            print(row_count)
            if not os.path.exists(outputFilePath):
                os.makedirs(outputFilePath)
            else: 
                pass 
            print(row_count)
            if row_count >= self.maxLineCount:
                for x in range(row_count):
                    if x % self.maxLineCount == 0:
                        print(x)
                        print(x+int(self.maxLineCount))
                        temp_df = df[x:x+int(self.maxLineCount)]
                        temp_df.to_csv(outputFilePath+"/"+"OutputFile"+str(x)+self.outputFileExtention, header = False)
            else:
                df.to_csv(outputFilePath+"/"+"OutputFile"+self.outputFileExtention, header = False)
            print("Files processed")
            end = time.time()
            process_latency = end - start
            self.logger.info("Files processed and output file is created")
            self.prog_logger.addLog(datetime.now(), "Files processed and output file is created")
            return {"outputFilePath": outputFilePath, "filesProcessed": True, "process_latency": process_latency}
        except:
            print("Error while processing the files")
            if len(os.listdir(processPath)) == 0:
                self.logger.info("Files not processed, files not present to process")
                self.prog_logger.addLog(datetime.now(), "Files not processed, files not present to process")
                print("Files not present to process")
            end = time.time()
            process_latency = end - start
            self.logger.info("Files not processed")
            self.prog_logger.addLog(datetime.now(), "Files not processed")
            return {"outputFilePath": outputFilePath, "filesProcessed": False, "process_latency": process_latency}
