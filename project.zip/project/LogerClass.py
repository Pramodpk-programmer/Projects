from datetime import datetime

class LoggerClass():
    
   
    def __init__(self):
        self.log = ""
        print("Writing log")

    def addLog(self, time, message):
        self.log  = self.log  + "time: "+str(time)+"  "+"log: "+message+","+"\n"

    def getLog(self):
        print(self.log)
        return self.log


