from flask import Flask, request
from datetime import datetime
import time
import os
from flask import json
from collections import OrderedDict
import logging
import csv
import collections

# Importing Classes
from InputClass import InputClass
from OutputClass import OutputClass
from ProcessClass import ProcessClass
from LogerClass import LoggerClass


dataUploader = Flask(__name__)



@dataUploader.route('/', methods = ['POST'])
def get():
    start = time.time()
    print("Process started")
    logging.basicConfig(filename="logfile.csv", format='%(asctime)s  %(message)s ', filemode='w')
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.info("Process Started")
    prog_log = LoggerClass()
    prog_log.addLog(datetime.now(), "Process started")
    projectSuccessDetails = OrderedDict()
    content = request.json
    input_type_list = content.get('steps').get('source').get('type')
    output_type_list = content.get('steps').get('destination').get('type')
    input_connection_type = None
    output_connection_type = None
    for type, value in zip(input_type_list, input_type_list.values()):
        if value == True:
            input_connection_type = type
            print("Input Connection is: ", input_connection_type)
            break
        else:
            continue
    for type, value in zip(output_type_list, output_type_list.values()):
        if value == True:
            output_connection_type = type
            print("Output Connection is: ", output_connection_type)
            break
        else:
            continue
    input_conn_parameters = content.get('steps').get('source').get('properties').get(input_connection_type)
    output_conn_parameters = content.get('steps').get('destination').get('properties').get(output_connection_type)
    process_parameters = content.get('steps').get('process').get('properties')

    # Creating Class Objects
    # Calling Input Class
    input_object = InputClass(input_conn_parameters, input_connection_type, logger, prog_log)
    input_response_obj = input_object.get_Files()
    source_latency = input_response_obj.get('source_latency')
    print("Source Latency is :" , source_latency)
    if (input_response_obj.get('filesDownloaded')):
        # Calling Process Class
        process_object = ProcessClass(process_parameters, logger, prog_log)
        print("Calling process class")
        process_response_obj = process_object.process((input_response_obj.get('processPath')))
        process_latency = process_response_obj.get('process_latency')
        if (process_response_obj.get('filesProcessed')):
            # Calling Output Class
            output_object = OutputClass(output_conn_parameters, output_connection_type, logger, prog_log)
            output_response_obj = output_object.put_Files((process_response_obj.get('outputFilePath')))
            print(output_response_obj)
            upload_latency = output_response_obj.get('destination_latency')
            # Success response
            if output_response_obj.get('files_uploaded'):
                output_File_Name = output_response_obj.get('OutputFileName')
                logger.info("Process Completed Successfully")
                prog_log.addLog(datetime.now(), "Process Completed Successfully")
                end = time.time()
                latency = end - start
                logs = ""
                with open('logfile.csv') as csv_file:
                    p = csv.reader(csv_file)
                    for x in p:
                        logs = logs + str(x)+ "," + '\n'
                print(logs)
                proj_log = prog_log.getLog()
                # Success JSON Response:
                projectSuccessDetails = '''{
"version": "1.0.0.0",
"projectName": "Advangelists",
"latency": {
    "Total_Time_Taken_To_Process": %f,
    "Time_Taken_To_Download_Files": %f,
    "Time_Taken_To_Process_Files": %f,
    "Time_Taken_To_Upload_Files": %f,
},
"audit-logs": {%s},
"output_file_name": %s
}''' %(latency, source_latency, process_latency, upload_latency, str(proj_log), output_File_Name)
                # projectSuccessDetails = collections.OrderedDict(projectSuccessDetails)
                print(projectSuccessDetails)
                return json.text_type(projectSuccessDetails), 200
            else:
                logger.info("Destination: Process failed to upload files")
                print("Destination: Process failed to upload files")
        else:
            print("Files not processed, there is no output file to upload")
            logger.info("Files not processed, there is no output file to upload")
            prog_log.addLog(datetime.now(), "Files not processed, there is no output file to upload")
    else:
        print("No files to process")
        logger.info("No files to process")
        prog_log.addLog(datetime.now(), "No files to process")
    # Failure response
    logger.info("Process failed")
    prog_log.addLog(datetime.now(), "Process failed")
    failed_logs = ""
    with open('logfile.csv') as csv_file:
        p = csv.reader(csv_file)
        for x in p:
            failed_logs = failed_logs + str(x)+ "," + '\n'
    print(failed_logs)
    proj_fail_log = ""
    proj_fail_log = prog_log.getLog()
    projectFailureDetails = '''{
"version": "1.0.0.0",
"projectName": "Advangelists",
"audit-logs": {%s},
}''' %(str(proj_fail_log))
    # f = open("logfile.csv", "w")
    # f.truncate()
    # f.close()
    return json.text_type(projectFailureDetails), 400

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 6000))
    dataUploader.run(debug=True, host='0.0.0.0', port=6000)